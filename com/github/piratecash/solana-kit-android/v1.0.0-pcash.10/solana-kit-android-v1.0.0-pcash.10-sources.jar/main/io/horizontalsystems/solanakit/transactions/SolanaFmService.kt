package io.horizontalsystems.solanakit.transactions

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.annotations.SerializedName
import io.horizontalsystems.solanakit.models.TokenInfo
import io.horizontalsystems.solanakit.network.SolanaNetworkErrorListener
import io.horizontalsystems.solanakit.network.emitSafely
import io.horizontalsystems.solanakit.network.toSolanaNetworkError
import io.reactivex.Single
import kotlinx.coroutines.rx2.await
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.converter.scalars.ScalarsConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import java.net.URL
import java.util.logging.Logger

class SolanaFmService(
    private val networkErrorListener: SolanaNetworkErrorListener? = null
) {

    private val baseUrl = URL("https://api.solana.fm/v1/")
    private val logger = Logger.getLogger("SolanaFmService")

    private val api: SolanaFmApi
    private val gson: Gson

    init {
        val loggingInterceptor = HttpLoggingInterceptor { message -> logger.info(message) }
            .setLevel(HttpLoggingInterceptor.Level.BASIC)

        val httpClient = OkHttpClient.Builder()
            .addInterceptor(loggingInterceptor)

        gson = GsonBuilder()
            .setLenient()
            .create()

        val retrofit = Retrofit.Builder()
            .baseUrl(baseUrl.toString())
            .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
            .addConverterFactory(ScalarsConverterFactory.create())
            .addConverterFactory(GsonConverterFactory.create(gson))
            .client(httpClient.build())
            .build()

        api = retrofit.create(SolanaFmApi::class.java)
    }

    suspend fun tokenInfo(mintAddress: String): TokenInfo {
        val response = request("GET", "tokens/$mintAddress") {
            api.tokenInfo(mintAddress).await()
        }

        return TokenInfo(
            name = response.tokenDetails.name,
            symbol = response.tokenDetails.symbol,
            decimals = response.decimals
        )
    }

    private suspend fun <T> request(
        method: String,
        path: String,
        block: suspend () -> T
    ): T = try {
        block()
    } catch (error: Throwable) {
        networkErrorListener.emitSafely {
            URL(baseUrl, path).toSolanaNetworkError(
                source = "solana-fm",
                method = method,
                throwable = error
            )
        }
        throw error
    }

    private interface SolanaFmApi {
        @GET("tokens/{mintAddress}")
        fun tokenInfo(
            @Path("mintAddress") mintAddress: String
        ): Single<TokenInfoResponse>
    }

    data class TokenInfoResponse(
        val mint: String,
        val decimals: Int,
        @SerializedName("tokenList")
        val tokenDetails: TokenInfoDetails
    )

    data class TokenInfoDetails(
        val name: String,
        val symbol: String
    )

}
