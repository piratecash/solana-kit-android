package io.horizontalsystems.solanakit.database.transaction.dao

import androidx.collection.ArrayMap
import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.util.appendPlaceholders
import androidx.room.util.getColumnIndex
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performBlocking
import androidx.room.util.recursiveFetchArrayMap
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.SQLiteStatement
import io.horizontalsystems.solanakit.database.transaction.RoomTypeConverters
import io.horizontalsystems.solanakit.models.MintAccount
import io.horizontalsystems.solanakit.models.TokenAccount
import java.math.BigDecimal
import javax.`annotation`.processing.Generated
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.Set
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlin.text.StringBuilder

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class TokenAccountDao_Impl(
  __db: RoomDatabase,
) : TokenAccountDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfTokenAccount: EntityInsertAdapter<TokenAccount>

  private val __roomTypeConverters: RoomTypeConverters = RoomTypeConverters()
  init {
    this.__db = __db
    this.__insertAdapterOfTokenAccount = object : EntityInsertAdapter<TokenAccount>() {
      protected override fun createQuery(): String =
          "INSERT OR REPLACE INTO `TokenAccount` (`address`,`mintAddress`,`balance`,`decimals`) VALUES (?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: TokenAccount) {
        statement.bindText(1, entity.address)
        statement.bindText(2, entity.mintAddress)
        val _tmp: String? = __roomTypeConverters.bigDecimalToString(entity.balance)
        if (_tmp == null) {
          statement.bindNull(3)
        } else {
          statement.bindText(3, _tmp)
        }
        statement.bindLong(4, entity.decimals.toLong())
      }
    }
  }

  public override fun insert(tokenAccount: TokenAccount): Unit = performBlocking(__db, false, true)
      { _connection ->
    __insertAdapterOfTokenAccount.insert(_connection, tokenAccount)
  }

  public override fun insert(balance: List<TokenAccount>): Unit = performBlocking(__db, false, true)
      { _connection ->
    __insertAdapterOfTokenAccount.insert(_connection, balance)
  }

  public override fun getByMintAddress(address: String): TokenAccount? {
    val _sql: String = "SELECT * FROM TokenAccount WHERE mintAddress=? LIMIT 1"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, address)
        val _columnIndexOfAddress: Int = getColumnIndexOrThrow(_stmt, "address")
        val _columnIndexOfMintAddress: Int = getColumnIndexOrThrow(_stmt, "mintAddress")
        val _columnIndexOfBalance: Int = getColumnIndexOrThrow(_stmt, "balance")
        val _columnIndexOfDecimals: Int = getColumnIndexOrThrow(_stmt, "decimals")
        val _result: TokenAccount?
        if (_stmt.step()) {
          val _tmpAddress: String
          _tmpAddress = _stmt.getText(_columnIndexOfAddress)
          val _tmpMintAddress: String
          _tmpMintAddress = _stmt.getText(_columnIndexOfMintAddress)
          val _tmpBalance: BigDecimal
          val _tmp: String?
          if (_stmt.isNull(_columnIndexOfBalance)) {
            _tmp = null
          } else {
            _tmp = _stmt.getText(_columnIndexOfBalance)
          }
          val _tmp_1: BigDecimal? = __roomTypeConverters.bigDecimalFromString(_tmp)
          if (_tmp_1 == null) {
            error("Expected NON-NULL 'java.math.BigDecimal', but it was NULL.")
          } else {
            _tmpBalance = _tmp_1
          }
          val _tmpDecimals: Int
          _tmpDecimals = _stmt.getLong(_columnIndexOfDecimals).toInt()
          _result = TokenAccount(_tmpAddress,_tmpMintAddress,_tmpBalance,_tmpDecimals)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun `get`(mintAddress: String): TokenAccountDao.TokenAccountWrapper? {
    val _sql: String = "SELECT * FROM TokenAccount WHERE mintAddress=? LIMIT 1"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, mintAddress)
        val _columnIndexOfAddress: Int = getColumnIndexOrThrow(_stmt, "address")
        val _columnIndexOfMintAddress: Int = getColumnIndexOrThrow(_stmt, "mintAddress")
        val _columnIndexOfBalance: Int = getColumnIndexOrThrow(_stmt, "balance")
        val _columnIndexOfDecimals: Int = getColumnIndexOrThrow(_stmt, "decimals")
        val _collectionMintAccount: ArrayMap<String, MintAccount?> =
            ArrayMap<String, MintAccount?>()
        while (_stmt.step()) {
          val _tmpKey: String
          _tmpKey = _stmt.getText(_columnIndexOfMintAddress)
          _collectionMintAccount.put(_tmpKey, null)
        }
        _stmt.reset()
        __fetchRelationshipMintAccountAsioHorizontalsystemsSolanakitModelsMintAccount(_connection,
            _collectionMintAccount)
        val _result: TokenAccountDao.TokenAccountWrapper?
        if (_stmt.step()) {
          val _tmpTokenAccount: TokenAccount
          val _tmpAddress: String
          _tmpAddress = _stmt.getText(_columnIndexOfAddress)
          val _tmpMintAddress: String
          _tmpMintAddress = _stmt.getText(_columnIndexOfMintAddress)
          val _tmpBalance: BigDecimal
          val _tmp: String?
          if (_stmt.isNull(_columnIndexOfBalance)) {
            _tmp = null
          } else {
            _tmp = _stmt.getText(_columnIndexOfBalance)
          }
          val _tmp_1: BigDecimal? = __roomTypeConverters.bigDecimalFromString(_tmp)
          if (_tmp_1 == null) {
            error("Expected NON-NULL 'java.math.BigDecimal', but it was NULL.")
          } else {
            _tmpBalance = _tmp_1
          }
          val _tmpDecimals: Int
          _tmpDecimals = _stmt.getLong(_columnIndexOfDecimals).toInt()
          _tmpTokenAccount = TokenAccount(_tmpAddress,_tmpMintAddress,_tmpBalance,_tmpDecimals)
          val _tmpMintAccount: MintAccount?
          val _tmpKey_1: String
          _tmpKey_1 = _stmt.getText(_columnIndexOfMintAddress)
          _tmpMintAccount = _collectionMintAccount.get(_tmpKey_1)
          if (_tmpMintAccount == null) {
            error("Relationship item 'mintAccount' was expected to be NON-NULL but is NULL in @Relation involving a parent column named 'mintAddress' and entityColumn named 'address'.")
          }
          _result = TokenAccountDao.TokenAccountWrapper(_tmpTokenAccount,_tmpMintAccount)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun `get`(mintAddresses: List<String>): List<TokenAccount> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM TokenAccount WHERE mintAddress IN (")
    val _inputSize: Int = mintAddresses.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: String in mintAddresses) {
          _stmt.bindText(_argIndex, _item)
          _argIndex++
        }
        val _columnIndexOfAddress: Int = getColumnIndexOrThrow(_stmt, "address")
        val _columnIndexOfMintAddress: Int = getColumnIndexOrThrow(_stmt, "mintAddress")
        val _columnIndexOfBalance: Int = getColumnIndexOrThrow(_stmt, "balance")
        val _columnIndexOfDecimals: Int = getColumnIndexOrThrow(_stmt, "decimals")
        val _result: MutableList<TokenAccount> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: TokenAccount
          val _tmpAddress: String
          _tmpAddress = _stmt.getText(_columnIndexOfAddress)
          val _tmpMintAddress: String
          _tmpMintAddress = _stmt.getText(_columnIndexOfMintAddress)
          val _tmpBalance: BigDecimal
          val _tmp: String?
          if (_stmt.isNull(_columnIndexOfBalance)) {
            _tmp = null
          } else {
            _tmp = _stmt.getText(_columnIndexOfBalance)
          }
          val _tmp_1: BigDecimal? = __roomTypeConverters.bigDecimalFromString(_tmp)
          if (_tmp_1 == null) {
            error("Expected NON-NULL 'java.math.BigDecimal', but it was NULL.")
          } else {
            _tmpBalance = _tmp_1
          }
          val _tmpDecimals: Int
          _tmpDecimals = _stmt.getLong(_columnIndexOfDecimals).toInt()
          _item_1 = TokenAccount(_tmpAddress,_tmpMintAddress,_tmpBalance,_tmpDecimals)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun getAll(): List<TokenAccount> {
    val _sql: String = "SELECT * FROM TokenAccount"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfAddress: Int = getColumnIndexOrThrow(_stmt, "address")
        val _columnIndexOfMintAddress: Int = getColumnIndexOrThrow(_stmt, "mintAddress")
        val _columnIndexOfBalance: Int = getColumnIndexOrThrow(_stmt, "balance")
        val _columnIndexOfDecimals: Int = getColumnIndexOrThrow(_stmt, "decimals")
        val _result: MutableList<TokenAccount> = mutableListOf()
        while (_stmt.step()) {
          val _item: TokenAccount
          val _tmpAddress: String
          _tmpAddress = _stmt.getText(_columnIndexOfAddress)
          val _tmpMintAddress: String
          _tmpMintAddress = _stmt.getText(_columnIndexOfMintAddress)
          val _tmpBalance: BigDecimal
          val _tmp: String?
          if (_stmt.isNull(_columnIndexOfBalance)) {
            _tmp = null
          } else {
            _tmp = _stmt.getText(_columnIndexOfBalance)
          }
          val _tmp_1: BigDecimal? = __roomTypeConverters.bigDecimalFromString(_tmp)
          if (_tmp_1 == null) {
            error("Expected NON-NULL 'java.math.BigDecimal', but it was NULL.")
          } else {
            _tmpBalance = _tmp_1
          }
          val _tmpDecimals: Int
          _tmpDecimals = _stmt.getLong(_columnIndexOfDecimals).toInt()
          _item = TokenAccount(_tmpAddress,_tmpMintAddress,_tmpBalance,_tmpDecimals)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun getAllFullAccounts(): List<TokenAccountDao.TokenAccountWrapper> {
    val _sql: String = "SELECT * FROM TokenAccount"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfAddress: Int = getColumnIndexOrThrow(_stmt, "address")
        val _columnIndexOfMintAddress: Int = getColumnIndexOrThrow(_stmt, "mintAddress")
        val _columnIndexOfBalance: Int = getColumnIndexOrThrow(_stmt, "balance")
        val _columnIndexOfDecimals: Int = getColumnIndexOrThrow(_stmt, "decimals")
        val _collectionMintAccount: ArrayMap<String, MintAccount?> =
            ArrayMap<String, MintAccount?>()
        while (_stmt.step()) {
          val _tmpKey: String
          _tmpKey = _stmt.getText(_columnIndexOfMintAddress)
          _collectionMintAccount.put(_tmpKey, null)
        }
        _stmt.reset()
        __fetchRelationshipMintAccountAsioHorizontalsystemsSolanakitModelsMintAccount(_connection,
            _collectionMintAccount)
        val _result: MutableList<TokenAccountDao.TokenAccountWrapper> = mutableListOf()
        while (_stmt.step()) {
          val _item: TokenAccountDao.TokenAccountWrapper
          val _tmpTokenAccount: TokenAccount
          val _tmpAddress: String
          _tmpAddress = _stmt.getText(_columnIndexOfAddress)
          val _tmpMintAddress: String
          _tmpMintAddress = _stmt.getText(_columnIndexOfMintAddress)
          val _tmpBalance: BigDecimal
          val _tmp: String?
          if (_stmt.isNull(_columnIndexOfBalance)) {
            _tmp = null
          } else {
            _tmp = _stmt.getText(_columnIndexOfBalance)
          }
          val _tmp_1: BigDecimal? = __roomTypeConverters.bigDecimalFromString(_tmp)
          if (_tmp_1 == null) {
            error("Expected NON-NULL 'java.math.BigDecimal', but it was NULL.")
          } else {
            _tmpBalance = _tmp_1
          }
          val _tmpDecimals: Int
          _tmpDecimals = _stmt.getLong(_columnIndexOfDecimals).toInt()
          _tmpTokenAccount = TokenAccount(_tmpAddress,_tmpMintAddress,_tmpBalance,_tmpDecimals)
          val _tmpMintAccount: MintAccount?
          val _tmpKey_1: String
          _tmpKey_1 = _stmt.getText(_columnIndexOfMintAddress)
          _tmpMintAccount = _collectionMintAccount.get(_tmpKey_1)
          if (_tmpMintAccount == null) {
            error("Relationship item 'mintAccount' was expected to be NON-NULL but is NULL in @Relation involving a parent column named 'mintAddress' and entityColumn named 'address'.")
          }
          _item = TokenAccountDao.TokenAccountWrapper(_tmpTokenAccount,_tmpMintAccount)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  private
      fun __fetchRelationshipMintAccountAsioHorizontalsystemsSolanakitModelsMintAccount(_connection: SQLiteConnection,
      _map: ArrayMap<String, MintAccount?>) {
    val __mapKeySet: Set<String> = _map.keys
    if (__mapKeySet.isEmpty()) {
      return
    }
    if (_map.size > 999) {
      recursiveFetchArrayMap(_map, false) { _tmpMap ->
        __fetchRelationshipMintAccountAsioHorizontalsystemsSolanakitModelsMintAccount(_connection,
            _tmpMap)
      }
      return
    }
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT `address`,`decimals`,`supply`,`isNft`,`name`,`symbol`,`uri`,`collectionAddress` FROM `MintAccount` WHERE `address` IN (")
    val _inputSize: Int = __mapKeySet.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    val _stmt: SQLiteStatement = _connection.prepare(_sql)
    var _argIndex: Int = 1
    for (_item: String in __mapKeySet) {
      _stmt.bindText(_argIndex, _item)
      _argIndex++
    }
    try {
      val _itemKeyIndex: Int = getColumnIndex(_stmt, "address")
      if (_itemKeyIndex == -1) {
        return
      }
      val _columnIndexOfAddress: Int = 0
      val _columnIndexOfDecimals: Int = 1
      val _columnIndexOfSupply: Int = 2
      val _columnIndexOfIsNft: Int = 3
      val _columnIndexOfName: Int = 4
      val _columnIndexOfSymbol: Int = 5
      val _columnIndexOfUri: Int = 6
      val _columnIndexOfCollectionAddress: Int = 7
      while (_stmt.step()) {
        val _tmpKey: String
        _tmpKey = _stmt.getText(_itemKeyIndex)
        if (_map.containsKey(_tmpKey)) {
          val _item_1: MintAccount
          val _tmpAddress: String
          _tmpAddress = _stmt.getText(_columnIndexOfAddress)
          val _tmpDecimals: Int
          _tmpDecimals = _stmt.getLong(_columnIndexOfDecimals).toInt()
          val _tmpSupply: Long?
          if (_stmt.isNull(_columnIndexOfSupply)) {
            _tmpSupply = null
          } else {
            _tmpSupply = _stmt.getLong(_columnIndexOfSupply)
          }
          val _tmpIsNft: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfIsNft).toInt()
          _tmpIsNft = _tmp != 0
          val _tmpName: String?
          if (_stmt.isNull(_columnIndexOfName)) {
            _tmpName = null
          } else {
            _tmpName = _stmt.getText(_columnIndexOfName)
          }
          val _tmpSymbol: String?
          if (_stmt.isNull(_columnIndexOfSymbol)) {
            _tmpSymbol = null
          } else {
            _tmpSymbol = _stmt.getText(_columnIndexOfSymbol)
          }
          val _tmpUri: String?
          if (_stmt.isNull(_columnIndexOfUri)) {
            _tmpUri = null
          } else {
            _tmpUri = _stmt.getText(_columnIndexOfUri)
          }
          val _tmpCollectionAddress: String?
          if (_stmt.isNull(_columnIndexOfCollectionAddress)) {
            _tmpCollectionAddress = null
          } else {
            _tmpCollectionAddress = _stmt.getText(_columnIndexOfCollectionAddress)
          }
          _item_1 =
              MintAccount(_tmpAddress,_tmpDecimals,_tmpSupply,_tmpIsNft,_tmpName,_tmpSymbol,_tmpUri,_tmpCollectionAddress)
          _map.put(_tmpKey, _item_1)
        }
      }
    } finally {
      _stmt.close()
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
