package io.horizontalsystems.solanakit.database.transaction.dao

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performBlocking
import androidx.sqlite.SQLiteStatement
import io.horizontalsystems.solanakit.models.LastSyncedTransaction
import javax.`annotation`.processing.Generated
import kotlin.Int
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class TransactionSyncerStateDao_Impl(
  __db: RoomDatabase,
) : TransactionSyncerStateDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfLastSyncedTransaction: EntityInsertAdapter<LastSyncedTransaction>
  init {
    this.__db = __db
    this.__insertAdapterOfLastSyncedTransaction = object :
        EntityInsertAdapter<LastSyncedTransaction>() {
      protected override fun createQuery(): String =
          "INSERT OR REPLACE INTO `LastSyncedTransaction` (`syncSourceName`,`hash`) VALUES (?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: LastSyncedTransaction) {
        statement.bindText(1, entity.syncSourceName)
        statement.bindText(2, entity.hash)
      }
    }
  }

  public override fun save(transactionSyncerState: LastSyncedTransaction): Unit =
      performBlocking(__db, false, true) { _connection ->
    __insertAdapterOfLastSyncedTransaction.insert(_connection, transactionSyncerState)
  }

  public override fun `get`(syncSourceName: String): LastSyncedTransaction? {
    val _sql: String = "SELECT * FROM LastSyncedTransaction WHERE syncSourceName = ? LIMIT 1"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, syncSourceName)
        val _columnIndexOfSyncSourceName: Int = getColumnIndexOrThrow(_stmt, "syncSourceName")
        val _columnIndexOfHash: Int = getColumnIndexOrThrow(_stmt, "hash")
        val _result: LastSyncedTransaction?
        if (_stmt.step()) {
          val _tmpSyncSourceName: String
          _tmpSyncSourceName = _stmt.getText(_columnIndexOfSyncSourceName)
          val _tmpHash: String
          _tmpHash = _stmt.getText(_columnIndexOfHash)
          _result = LastSyncedTransaction(_tmpSyncSourceName,_tmpHash)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
