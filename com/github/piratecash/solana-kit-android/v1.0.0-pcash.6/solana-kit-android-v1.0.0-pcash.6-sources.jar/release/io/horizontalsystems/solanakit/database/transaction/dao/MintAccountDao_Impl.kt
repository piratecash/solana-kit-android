package io.horizontalsystems.solanakit.database.transaction.dao

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performBlocking
import androidx.room.util.performSuspending
import androidx.sqlite.SQLiteStatement
import io.horizontalsystems.solanakit.models.MintAccount
import javax.`annotation`.processing.Generated
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class MintAccountDao_Impl(
  __db: RoomDatabase,
) : MintAccountDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfMintAccount: EntityInsertAdapter<MintAccount>
  init {
    this.__db = __db
    this.__insertAdapterOfMintAccount = object : EntityInsertAdapter<MintAccount>() {
      protected override fun createQuery(): String =
          "INSERT OR IGNORE INTO `MintAccount` (`address`,`decimals`,`supply`,`isNft`,`name`,`symbol`,`uri`,`collectionAddress`) VALUES (?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: MintAccount) {
        statement.bindText(1, entity.address)
        statement.bindLong(2, entity.decimals.toLong())
        val _tmpSupply: Long? = entity.supply
        if (_tmpSupply == null) {
          statement.bindNull(3)
        } else {
          statement.bindLong(3, _tmpSupply)
        }
        val _tmp: Int = if (entity.isNft) 1 else 0
        statement.bindLong(4, _tmp.toLong())
        val _tmpName: String? = entity.name
        if (_tmpName == null) {
          statement.bindNull(5)
        } else {
          statement.bindText(5, _tmpName)
        }
        val _tmpSymbol: String? = entity.symbol
        if (_tmpSymbol == null) {
          statement.bindNull(6)
        } else {
          statement.bindText(6, _tmpSymbol)
        }
        val _tmpUri: String? = entity.uri
        if (_tmpUri == null) {
          statement.bindNull(7)
        } else {
          statement.bindText(7, _tmpUri)
        }
        val _tmpCollectionAddress: String? = entity.collectionAddress
        if (_tmpCollectionAddress == null) {
          statement.bindNull(8)
        } else {
          statement.bindText(8, _tmpCollectionAddress)
        }
      }
    }
  }

  public override fun insert(mintAccount: MintAccount): Unit = performBlocking(__db, false, true) {
      _connection ->
    __insertAdapterOfMintAccount.insert(_connection, mintAccount)
  }

  public override fun insert(accounts: List<MintAccount>): Unit = performBlocking(__db, false, true)
      { _connection ->
    __insertAdapterOfMintAccount.insert(_connection, accounts)
  }

  public override suspend fun `get`(address: String): MintAccount? {
    val _sql: String = "SELECT * FROM `MintAccount` WHERE address = ? LIMIT 1"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, address)
        val _columnIndexOfAddress: Int = getColumnIndexOrThrow(_stmt, "address")
        val _columnIndexOfDecimals: Int = getColumnIndexOrThrow(_stmt, "decimals")
        val _columnIndexOfSupply: Int = getColumnIndexOrThrow(_stmt, "supply")
        val _columnIndexOfIsNft: Int = getColumnIndexOrThrow(_stmt, "isNft")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfSymbol: Int = getColumnIndexOrThrow(_stmt, "symbol")
        val _columnIndexOfUri: Int = getColumnIndexOrThrow(_stmt, "uri")
        val _columnIndexOfCollectionAddress: Int = getColumnIndexOrThrow(_stmt, "collectionAddress")
        val _result: MintAccount?
        if (_stmt.step()) {
          val _tmpAddress: String
          _tmpAddress = _stmt.getText(_columnIndexOfAddress)
          val _tmpDecimals: Int
          _tmpDecimals = _stmt.getLong(_columnIndexOfDecimals).toInt()
          val _tmpSupply: Long?
          if (_stmt.isNull(_columnIndexOfSupply)) {
            _tmpSupply = null
          } else {
            _tmpSupply = _stmt.getLong(_columnIndexOfSupply)
          }
          val _tmpIsNft: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfIsNft).toInt()
          _tmpIsNft = _tmp != 0
          val _tmpName: String?
          if (_stmt.isNull(_columnIndexOfName)) {
            _tmpName = null
          } else {
            _tmpName = _stmt.getText(_columnIndexOfName)
          }
          val _tmpSymbol: String?
          if (_stmt.isNull(_columnIndexOfSymbol)) {
            _tmpSymbol = null
          } else {
            _tmpSymbol = _stmt.getText(_columnIndexOfSymbol)
          }
          val _tmpUri: String?
          if (_stmt.isNull(_columnIndexOfUri)) {
            _tmpUri = null
          } else {
            _tmpUri = _stmt.getText(_columnIndexOfUri)
          }
          val _tmpCollectionAddress: String?
          if (_stmt.isNull(_columnIndexOfCollectionAddress)) {
            _tmpCollectionAddress = null
          } else {
            _tmpCollectionAddress = _stmt.getText(_columnIndexOfCollectionAddress)
          }
          _result =
              MintAccount(_tmpAddress,_tmpDecimals,_tmpSupply,_tmpIsNft,_tmpName,_tmpSymbol,_tmpUri,_tmpCollectionAddress)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
