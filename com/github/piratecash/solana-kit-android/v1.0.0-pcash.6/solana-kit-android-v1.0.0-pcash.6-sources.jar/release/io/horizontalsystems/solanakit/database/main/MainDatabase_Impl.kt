package io.horizontalsystems.solanakit.database.main

import androidx.room.InvalidationTracker
import androidx.room.RoomOpenDelegate
import androidx.room.migration.AutoMigrationSpec
import androidx.room.migration.Migration
import androidx.room.util.TableInfo
import androidx.room.util.TableInfo.Companion.read
import androidx.room.util.dropFtsSyncTriggers
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.execSQL
import io.horizontalsystems.solanakit.database.main.dao.BalanceDao
import io.horizontalsystems.solanakit.database.main.dao.BalanceDao_Impl
import io.horizontalsystems.solanakit.database.main.dao.InitialSyncDao
import io.horizontalsystems.solanakit.database.main.dao.InitialSyncDao_Impl
import io.horizontalsystems.solanakit.database.main.dao.LastBlockHeightDao
import io.horizontalsystems.solanakit.database.main.dao.LastBlockHeightDao_Impl
import javax.`annotation`.processing.Generated
import kotlin.Lazy
import kotlin.String
import kotlin.Suppress
import kotlin.collections.List
import kotlin.collections.Map
import kotlin.collections.MutableList
import kotlin.collections.MutableMap
import kotlin.collections.MutableSet
import kotlin.collections.Set
import kotlin.collections.mutableListOf
import kotlin.collections.mutableMapOf
import kotlin.collections.mutableSetOf
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class MainDatabase_Impl : MainDatabase() {
  private val _balanceDao: Lazy<BalanceDao> = lazy {
    BalanceDao_Impl(this)
  }

  private val _lastBlockHeightDao: Lazy<LastBlockHeightDao> = lazy {
    LastBlockHeightDao_Impl(this)
  }

  private val _initialSyncDao: Lazy<InitialSyncDao> = lazy {
    InitialSyncDao_Impl(this)
  }

  protected override fun createOpenDelegate(): RoomOpenDelegate {
    val _openDelegate: RoomOpenDelegate = object : RoomOpenDelegate(5,
        "fc089dba6860a73fae13b61a6c01c764", "becfe2cb8dd830ccbfee4730d24c5453") {
      public override fun createAllTables(connection: SQLiteConnection) {
        connection.execSQL("CREATE TABLE IF NOT EXISTS `BalanceEntity` (`lamports` INTEGER NOT NULL, `id` TEXT NOT NULL, PRIMARY KEY(`id`))")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `LastBlockHeightEntity` (`height` INTEGER NOT NULL, `id` TEXT NOT NULL, PRIMARY KEY(`id`))")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `InitialSyncEntity` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `initial` INTEGER NOT NULL)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)")
        connection.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, 'fc089dba6860a73fae13b61a6c01c764')")
      }

      public override fun dropAllTables(connection: SQLiteConnection) {
        connection.execSQL("DROP TABLE IF EXISTS `BalanceEntity`")
        connection.execSQL("DROP TABLE IF EXISTS `LastBlockHeightEntity`")
        connection.execSQL("DROP TABLE IF EXISTS `InitialSyncEntity`")
      }

      public override fun onCreate(connection: SQLiteConnection) {
      }

      public override fun onOpen(connection: SQLiteConnection) {
        internalInitInvalidationTracker(connection)
      }

      public override fun onPreMigrate(connection: SQLiteConnection) {
        dropFtsSyncTriggers(connection)
      }

      public override fun onPostMigrate(connection: SQLiteConnection) {
      }

      public override fun onValidateSchema(connection: SQLiteConnection):
          RoomOpenDelegate.ValidationResult {
        val _columnsBalanceEntity: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsBalanceEntity.put("lamports", TableInfo.Column("lamports", "INTEGER", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsBalanceEntity.put("id", TableInfo.Column("id", "TEXT", true, 1, null,
            TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysBalanceEntity: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesBalanceEntity: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoBalanceEntity: TableInfo = TableInfo("BalanceEntity", _columnsBalanceEntity,
            _foreignKeysBalanceEntity, _indicesBalanceEntity)
        val _existingBalanceEntity: TableInfo = read(connection, "BalanceEntity")
        if (!_infoBalanceEntity.equals(_existingBalanceEntity)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |BalanceEntity(io.horizontalsystems.solanakit.models.BalanceEntity).
              | Expected:
              |""".trimMargin() + _infoBalanceEntity + """
              |
              | Found:
              |""".trimMargin() + _existingBalanceEntity)
        }
        val _columnsLastBlockHeightEntity: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsLastBlockHeightEntity.put("height", TableInfo.Column("height", "INTEGER", true, 0,
            null, TableInfo.CREATED_FROM_ENTITY))
        _columnsLastBlockHeightEntity.put("id", TableInfo.Column("id", "TEXT", true, 1, null,
            TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysLastBlockHeightEntity: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesLastBlockHeightEntity: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoLastBlockHeightEntity: TableInfo = TableInfo("LastBlockHeightEntity",
            _columnsLastBlockHeightEntity, _foreignKeysLastBlockHeightEntity,
            _indicesLastBlockHeightEntity)
        val _existingLastBlockHeightEntity: TableInfo = read(connection, "LastBlockHeightEntity")
        if (!_infoLastBlockHeightEntity.equals(_existingLastBlockHeightEntity)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |LastBlockHeightEntity(io.horizontalsystems.solanakit.models.LastBlockHeightEntity).
              | Expected:
              |""".trimMargin() + _infoLastBlockHeightEntity + """
              |
              | Found:
              |""".trimMargin() + _existingLastBlockHeightEntity)
        }
        val _columnsInitialSyncEntity: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsInitialSyncEntity.put("id", TableInfo.Column("id", "INTEGER", true, 1, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsInitialSyncEntity.put("initial", TableInfo.Column("initial", "INTEGER", true, 0,
            null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysInitialSyncEntity: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesInitialSyncEntity: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoInitialSyncEntity: TableInfo = TableInfo("InitialSyncEntity",
            _columnsInitialSyncEntity, _foreignKeysInitialSyncEntity, _indicesInitialSyncEntity)
        val _existingInitialSyncEntity: TableInfo = read(connection, "InitialSyncEntity")
        if (!_infoInitialSyncEntity.equals(_existingInitialSyncEntity)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |InitialSyncEntity(io.horizontalsystems.solanakit.models.InitialSyncEntity).
              | Expected:
              |""".trimMargin() + _infoInitialSyncEntity + """
              |
              | Found:
              |""".trimMargin() + _existingInitialSyncEntity)
        }
        return RoomOpenDelegate.ValidationResult(true, null)
      }
    }
    return _openDelegate
  }

  protected override fun createInvalidationTracker(): InvalidationTracker {
    val _shadowTablesMap: MutableMap<String, String> = mutableMapOf()
    val _viewTables: MutableMap<String, Set<String>> = mutableMapOf()
    return InvalidationTracker(this, _shadowTablesMap, _viewTables, "BalanceEntity",
        "LastBlockHeightEntity", "InitialSyncEntity")
  }

  public override fun clearAllTables() {
    super.performClear(false, "BalanceEntity", "LastBlockHeightEntity", "InitialSyncEntity")
  }

  protected override fun getRequiredTypeConverterClasses(): Map<KClass<*>, List<KClass<*>>> {
    val _typeConvertersMap: MutableMap<KClass<*>, List<KClass<*>>> = mutableMapOf()
    _typeConvertersMap.put(BalanceDao::class, BalanceDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(LastBlockHeightDao::class,
        LastBlockHeightDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(InitialSyncDao::class, InitialSyncDao_Impl.getRequiredConverters())
    return _typeConvertersMap
  }

  public override fun getRequiredAutoMigrationSpecClasses(): Set<KClass<out AutoMigrationSpec>> {
    val _autoMigrationSpecsSet: MutableSet<KClass<out AutoMigrationSpec>> = mutableSetOf()
    return _autoMigrationSpecsSet
  }

  public override
      fun createAutoMigrations(autoMigrationSpecs: Map<KClass<out AutoMigrationSpec>, AutoMigrationSpec>):
      List<Migration> {
    val _autoMigrations: MutableList<Migration> = mutableListOf()
    return _autoMigrations
  }

  public override fun balanceDao(): BalanceDao = _balanceDao.value

  public override fun lastBlockHeightDao(): LastBlockHeightDao = _lastBlockHeightDao.value

  public override fun initialSyncDao(): InitialSyncDao = _initialSyncDao.value
}
