package io.horizontalsystems.solanakit.database.main.dao

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performBlocking
import androidx.sqlite.SQLiteStatement
import io.horizontalsystems.solanakit.models.BalanceEntity
import javax.`annotation`.processing.Generated
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class BalanceDao_Impl(
  __db: RoomDatabase,
) : BalanceDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfBalanceEntity: EntityInsertAdapter<BalanceEntity>
  init {
    this.__db = __db
    this.__insertAdapterOfBalanceEntity = object : EntityInsertAdapter<BalanceEntity>() {
      protected override fun createQuery(): String =
          "INSERT OR REPLACE INTO `BalanceEntity` (`lamports`,`id`) VALUES (?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: BalanceEntity) {
        statement.bindLong(1, entity.lamports)
        statement.bindText(2, entity.id)
      }
    }
  }

  public override fun insert(balance: BalanceEntity): Unit = performBlocking(__db, false, true) {
      _connection ->
    __insertAdapterOfBalanceEntity.insert(_connection, balance)
  }

  public override fun getBalance(): BalanceEntity? {
    val _sql: String = "SELECT * FROM BalanceEntity"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfLamports: Int = getColumnIndexOrThrow(_stmt, "lamports")
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _result: BalanceEntity?
        if (_stmt.step()) {
          val _tmpLamports: Long
          _tmpLamports = _stmt.getLong(_columnIndexOfLamports)
          val _tmpId: String
          _tmpId = _stmt.getText(_columnIndexOfId)
          _result = BalanceEntity(_tmpLamports,_tmpId)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
