package io.horizontalsystems.solanakit.database.main.dao

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performBlocking
import androidx.sqlite.SQLiteStatement
import io.horizontalsystems.solanakit.models.InitialSyncEntity
import javax.`annotation`.processing.Generated
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class InitialSyncDao_Impl(
  __db: RoomDatabase,
) : InitialSyncDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfInitialSyncEntity: EntityInsertAdapter<InitialSyncEntity>
  init {
    this.__db = __db
    this.__insertAdapterOfInitialSyncEntity = object : EntityInsertAdapter<InitialSyncEntity>() {
      protected override fun createQuery(): String =
          "INSERT OR REPLACE INTO `InitialSyncEntity` (`id`,`initial`) VALUES (nullif(?, 0),?)"

      protected override fun bind(statement: SQLiteStatement, entity: InitialSyncEntity) {
        statement.bindLong(1, entity.id)
        val _tmp: Int = if (entity.initial) 1 else 0
        statement.bindLong(2, _tmp.toLong())
      }
    }
  }

  public override fun insert(entity: InitialSyncEntity): Unit = performBlocking(__db, false, true) {
      _connection ->
    __insertAdapterOfInitialSyncEntity.insert(_connection, entity)
  }

  public override fun getAllEntities(): List<InitialSyncEntity> {
    val _sql: String = "SELECT * FROM InitialSyncEntity"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfInitial: Int = getColumnIndexOrThrow(_stmt, "initial")
        val _result: MutableList<InitialSyncEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: InitialSyncEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpInitial: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfInitial).toInt()
          _tmpInitial = _tmp != 0
          _item = InitialSyncEntity(_tmpId,_tmpInitial)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
