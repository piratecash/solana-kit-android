package io.horizontalsystems.solanakit.database.transaction

import androidx.room.InvalidationTracker
import androidx.room.RoomOpenDelegate
import androidx.room.migration.AutoMigrationSpec
import androidx.room.migration.Migration
import androidx.room.util.TableInfo
import androidx.room.util.TableInfo.Companion.read
import androidx.room.util.dropFtsSyncTriggers
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.execSQL
import io.horizontalsystems.solanakit.database.transaction.dao.MintAccountDao
import io.horizontalsystems.solanakit.database.transaction.dao.MintAccountDao_Impl
import io.horizontalsystems.solanakit.database.transaction.dao.TokenAccountDao
import io.horizontalsystems.solanakit.database.transaction.dao.TokenAccountDao_Impl
import io.horizontalsystems.solanakit.database.transaction.dao.TransactionSyncerStateDao
import io.horizontalsystems.solanakit.database.transaction.dao.TransactionSyncerStateDao_Impl
import io.horizontalsystems.solanakit.database.transaction.dao.TransactionsDao
import io.horizontalsystems.solanakit.database.transaction.dao.TransactionsDao_Impl
import javax.`annotation`.processing.Generated
import kotlin.Lazy
import kotlin.String
import kotlin.Suppress
import kotlin.collections.List
import kotlin.collections.Map
import kotlin.collections.MutableList
import kotlin.collections.MutableMap
import kotlin.collections.MutableSet
import kotlin.collections.Set
import kotlin.collections.mutableListOf
import kotlin.collections.mutableMapOf
import kotlin.collections.mutableSetOf
import kotlin.reflect.KClass

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class TransactionDatabase_Impl : TransactionDatabase() {
  private val _transactionSyncerStateDao: Lazy<TransactionSyncerStateDao> = lazy {
    TransactionSyncerStateDao_Impl(this)
  }

  private val _transactionsDao: Lazy<TransactionsDao> = lazy {
    TransactionsDao_Impl(this)
  }

  private val _mintAccountDao: Lazy<MintAccountDao> = lazy {
    MintAccountDao_Impl(this)
  }

  private val _tokenAccountDao: Lazy<TokenAccountDao> = lazy {
    TokenAccountDao_Impl(this)
  }

  protected override fun createOpenDelegate(): RoomOpenDelegate {
    val _openDelegate: RoomOpenDelegate = object : RoomOpenDelegate(10,
        "f2914943655ac6ac53888c1f8db5cd58", "237ee3fd9f611456a228f224161676a4") {
      public override fun createAllTables(connection: SQLiteConnection) {
        connection.execSQL("CREATE TABLE IF NOT EXISTS `LastSyncedTransaction` (`syncSourceName` TEXT NOT NULL, `hash` TEXT NOT NULL, PRIMARY KEY(`syncSourceName`))")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `MintAccount` (`address` TEXT NOT NULL, `decimals` INTEGER NOT NULL, `supply` INTEGER, `isNft` INTEGER NOT NULL, `name` TEXT, `symbol` TEXT, `uri` TEXT, `collectionAddress` TEXT, PRIMARY KEY(`address`))")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `TokenTransfer` (`transactionHash` TEXT NOT NULL, `mintAddress` TEXT NOT NULL, `incoming` INTEGER NOT NULL, `amount` TEXT NOT NULL, `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, FOREIGN KEY(`transactionHash`) REFERENCES `Transaction`(`hash`) ON UPDATE NO ACTION ON DELETE CASCADE )")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_TokenTransfer_transactionHash` ON `TokenTransfer` (`transactionHash`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `Transaction` (`hash` TEXT NOT NULL, `timestamp` INTEGER NOT NULL, `fee` TEXT, `from` TEXT, `to` TEXT, `amount` TEXT, `error` TEXT, `pending` INTEGER NOT NULL, `blockHash` TEXT NOT NULL, `lastValidBlockHeight` INTEGER NOT NULL, `base64Encoded` TEXT NOT NULL, `retryCount` INTEGER NOT NULL, PRIMARY KEY(`hash`))")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `TokenAccount` (`address` TEXT NOT NULL, `mintAddress` TEXT NOT NULL, `balance` TEXT NOT NULL, `decimals` INTEGER NOT NULL, PRIMARY KEY(`address`))")
        connection.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)")
        connection.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, 'f2914943655ac6ac53888c1f8db5cd58')")
      }

      public override fun dropAllTables(connection: SQLiteConnection) {
        connection.execSQL("DROP TABLE IF EXISTS `LastSyncedTransaction`")
        connection.execSQL("DROP TABLE IF EXISTS `MintAccount`")
        connection.execSQL("DROP TABLE IF EXISTS `TokenTransfer`")
        connection.execSQL("DROP TABLE IF EXISTS `Transaction`")
        connection.execSQL("DROP TABLE IF EXISTS `TokenAccount`")
      }

      public override fun onCreate(connection: SQLiteConnection) {
      }

      public override fun onOpen(connection: SQLiteConnection) {
        connection.execSQL("PRAGMA foreign_keys = ON")
        internalInitInvalidationTracker(connection)
      }

      public override fun onPreMigrate(connection: SQLiteConnection) {
        dropFtsSyncTriggers(connection)
      }

      public override fun onPostMigrate(connection: SQLiteConnection) {
      }

      public override fun onValidateSchema(connection: SQLiteConnection):
          RoomOpenDelegate.ValidationResult {
        val _columnsLastSyncedTransaction: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsLastSyncedTransaction.put("syncSourceName", TableInfo.Column("syncSourceName",
            "TEXT", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsLastSyncedTransaction.put("hash", TableInfo.Column("hash", "TEXT", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysLastSyncedTransaction: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesLastSyncedTransaction: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoLastSyncedTransaction: TableInfo = TableInfo("LastSyncedTransaction",
            _columnsLastSyncedTransaction, _foreignKeysLastSyncedTransaction,
            _indicesLastSyncedTransaction)
        val _existingLastSyncedTransaction: TableInfo = read(connection, "LastSyncedTransaction")
        if (!_infoLastSyncedTransaction.equals(_existingLastSyncedTransaction)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |LastSyncedTransaction(io.horizontalsystems.solanakit.models.LastSyncedTransaction).
              | Expected:
              |""".trimMargin() + _infoLastSyncedTransaction + """
              |
              | Found:
              |""".trimMargin() + _existingLastSyncedTransaction)
        }
        val _columnsMintAccount: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsMintAccount.put("address", TableInfo.Column("address", "TEXT", true, 1, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsMintAccount.put("decimals", TableInfo.Column("decimals", "INTEGER", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsMintAccount.put("supply", TableInfo.Column("supply", "INTEGER", false, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsMintAccount.put("isNft", TableInfo.Column("isNft", "INTEGER", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsMintAccount.put("name", TableInfo.Column("name", "TEXT", false, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsMintAccount.put("symbol", TableInfo.Column("symbol", "TEXT", false, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsMintAccount.put("uri", TableInfo.Column("uri", "TEXT", false, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsMintAccount.put("collectionAddress", TableInfo.Column("collectionAddress", "TEXT",
            false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysMintAccount: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesMintAccount: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoMintAccount: TableInfo = TableInfo("MintAccount", _columnsMintAccount,
            _foreignKeysMintAccount, _indicesMintAccount)
        val _existingMintAccount: TableInfo = read(connection, "MintAccount")
        if (!_infoMintAccount.equals(_existingMintAccount)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |MintAccount(io.horizontalsystems.solanakit.models.MintAccount).
              | Expected:
              |""".trimMargin() + _infoMintAccount + """
              |
              | Found:
              |""".trimMargin() + _existingMintAccount)
        }
        val _columnsTokenTransfer: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsTokenTransfer.put("transactionHash", TableInfo.Column("transactionHash", "TEXT",
            true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTokenTransfer.put("mintAddress", TableInfo.Column("mintAddress", "TEXT", true, 0,
            null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTokenTransfer.put("incoming", TableInfo.Column("incoming", "INTEGER", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsTokenTransfer.put("amount", TableInfo.Column("amount", "TEXT", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsTokenTransfer.put("id", TableInfo.Column("id", "INTEGER", true, 1, null,
            TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysTokenTransfer: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        _foreignKeysTokenTransfer.add(TableInfo.ForeignKey("Transaction", "CASCADE", "NO ACTION",
            listOf("transactionHash"), listOf("hash")))
        val _indicesTokenTransfer: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesTokenTransfer.add(TableInfo.Index("index_TokenTransfer_transactionHash", false,
            listOf("transactionHash"), listOf("ASC")))
        val _infoTokenTransfer: TableInfo = TableInfo("TokenTransfer", _columnsTokenTransfer,
            _foreignKeysTokenTransfer, _indicesTokenTransfer)
        val _existingTokenTransfer: TableInfo = read(connection, "TokenTransfer")
        if (!_infoTokenTransfer.equals(_existingTokenTransfer)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |TokenTransfer(io.horizontalsystems.solanakit.models.TokenTransfer).
              | Expected:
              |""".trimMargin() + _infoTokenTransfer + """
              |
              | Found:
              |""".trimMargin() + _existingTokenTransfer)
        }
        val _columnsTransaction: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsTransaction.put("hash", TableInfo.Column("hash", "TEXT", true, 1, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsTransaction.put("timestamp", TableInfo.Column("timestamp", "INTEGER", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsTransaction.put("fee", TableInfo.Column("fee", "TEXT", false, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsTransaction.put("from", TableInfo.Column("from", "TEXT", false, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsTransaction.put("to", TableInfo.Column("to", "TEXT", false, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsTransaction.put("amount", TableInfo.Column("amount", "TEXT", false, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsTransaction.put("error", TableInfo.Column("error", "TEXT", false, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsTransaction.put("pending", TableInfo.Column("pending", "INTEGER", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsTransaction.put("blockHash", TableInfo.Column("blockHash", "TEXT", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsTransaction.put("lastValidBlockHeight", TableInfo.Column("lastValidBlockHeight",
            "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTransaction.put("base64Encoded", TableInfo.Column("base64Encoded", "TEXT", true, 0,
            null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTransaction.put("retryCount", TableInfo.Column("retryCount", "INTEGER", true, 0,
            null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysTransaction: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesTransaction: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoTransaction: TableInfo = TableInfo("Transaction", _columnsTransaction,
            _foreignKeysTransaction, _indicesTransaction)
        val _existingTransaction: TableInfo = read(connection, "Transaction")
        if (!_infoTransaction.equals(_existingTransaction)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |Transaction(io.horizontalsystems.solanakit.models.Transaction).
              | Expected:
              |""".trimMargin() + _infoTransaction + """
              |
              | Found:
              |""".trimMargin() + _existingTransaction)
        }
        val _columnsTokenAccount: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsTokenAccount.put("address", TableInfo.Column("address", "TEXT", true, 1, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsTokenAccount.put("mintAddress", TableInfo.Column("mintAddress", "TEXT", true, 0,
            null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTokenAccount.put("balance", TableInfo.Column("balance", "TEXT", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        _columnsTokenAccount.put("decimals", TableInfo.Column("decimals", "INTEGER", true, 0, null,
            TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysTokenAccount: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesTokenAccount: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoTokenAccount: TableInfo = TableInfo("TokenAccount", _columnsTokenAccount,
            _foreignKeysTokenAccount, _indicesTokenAccount)
        val _existingTokenAccount: TableInfo = read(connection, "TokenAccount")
        if (!_infoTokenAccount.equals(_existingTokenAccount)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |TokenAccount(io.horizontalsystems.solanakit.models.TokenAccount).
              | Expected:
              |""".trimMargin() + _infoTokenAccount + """
              |
              | Found:
              |""".trimMargin() + _existingTokenAccount)
        }
        return RoomOpenDelegate.ValidationResult(true, null)
      }
    }
    return _openDelegate
  }

  protected override fun createInvalidationTracker(): InvalidationTracker {
    val _shadowTablesMap: MutableMap<String, String> = mutableMapOf()
    val _viewTables: MutableMap<String, Set<String>> = mutableMapOf()
    return InvalidationTracker(this, _shadowTablesMap, _viewTables, "LastSyncedTransaction",
        "MintAccount", "TokenTransfer", "Transaction", "TokenAccount")
  }

  public override fun clearAllTables() {
    super.performClear(true, "LastSyncedTransaction", "MintAccount", "TokenTransfer", "Transaction",
        "TokenAccount")
  }

  protected override fun getRequiredTypeConverterClasses(): Map<KClass<*>, List<KClass<*>>> {
    val _typeConvertersMap: MutableMap<KClass<*>, List<KClass<*>>> = mutableMapOf()
    _typeConvertersMap.put(TransactionSyncerStateDao::class,
        TransactionSyncerStateDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(TransactionsDao::class, TransactionsDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(MintAccountDao::class, MintAccountDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(TokenAccountDao::class, TokenAccountDao_Impl.getRequiredConverters())
    return _typeConvertersMap
  }

  public override fun getRequiredAutoMigrationSpecClasses(): Set<KClass<out AutoMigrationSpec>> {
    val _autoMigrationSpecsSet: MutableSet<KClass<out AutoMigrationSpec>> = mutableSetOf()
    return _autoMigrationSpecsSet
  }

  public override
      fun createAutoMigrations(autoMigrationSpecs: Map<KClass<out AutoMigrationSpec>, AutoMigrationSpec>):
      List<Migration> {
    val _autoMigrations: MutableList<Migration> = mutableListOf()
    return _autoMigrations
  }

  public override fun transactionSyncerStateDao(): TransactionSyncerStateDao =
      _transactionSyncerStateDao.value

  public override fun transactionsDao(): TransactionsDao = _transactionsDao.value

  public override fun mintAccountDao(): MintAccountDao = _mintAccountDao.value

  public override fun tokenAccountsDao(): TokenAccountDao = _tokenAccountDao.value
}
