package io.horizontalsystems.solanakit.database.transaction.dao

import androidx.collection.ArrayMap
import androidx.room.EntityDeleteOrUpdateAdapter
import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.RoomRawQuery
import androidx.room.RoomSQLiteQuery
import androidx.room.util.appendPlaceholders
import androidx.room.util.getColumnIndex
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performBlocking
import androidx.room.util.performSuspending
import androidx.room.util.recursiveFetchArrayMap
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.SQLiteStatement
import androidx.sqlite.db.SupportSQLiteQuery
import io.horizontalsystems.solanakit.database.transaction.RoomTypeConverters
import io.horizontalsystems.solanakit.models.MintAccount
import io.horizontalsystems.solanakit.models.TokenTransfer
import io.horizontalsystems.solanakit.models.Transaction
import java.math.BigDecimal
import javax.`annotation`.processing.Generated
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.Set
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlin.text.StringBuilder

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class TransactionsDao_Impl(
  __db: RoomDatabase,
) : TransactionsDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfTransaction: EntityInsertAdapter<Transaction>

  private val __roomTypeConverters: RoomTypeConverters = RoomTypeConverters()

  private val __insertAdapterOfTokenTransfer: EntityInsertAdapter<TokenTransfer>

  private val __updateAdapterOfTransaction: EntityDeleteOrUpdateAdapter<Transaction>
  init {
    this.__db = __db
    this.__insertAdapterOfTransaction = object : EntityInsertAdapter<Transaction>() {
      protected override fun createQuery(): String =
          "INSERT OR REPLACE INTO `Transaction` (`hash`,`timestamp`,`fee`,`from`,`to`,`amount`,`error`,`pending`,`blockHash`,`lastValidBlockHeight`,`base64Encoded`,`retryCount`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: Transaction) {
        statement.bindText(1, entity.hash)
        statement.bindLong(2, entity.timestamp)
        val _tmpFee: BigDecimal? = entity.fee
        val _tmp: String? = __roomTypeConverters.bigDecimalToString(_tmpFee)
        if (_tmp == null) {
          statement.bindNull(3)
        } else {
          statement.bindText(3, _tmp)
        }
        val _tmpFrom: String? = entity.from
        if (_tmpFrom == null) {
          statement.bindNull(4)
        } else {
          statement.bindText(4, _tmpFrom)
        }
        val _tmpTo: String? = entity.to
        if (_tmpTo == null) {
          statement.bindNull(5)
        } else {
          statement.bindText(5, _tmpTo)
        }
        val _tmpAmount: BigDecimal? = entity.amount
        val _tmp_1: String? = __roomTypeConverters.bigDecimalToString(_tmpAmount)
        if (_tmp_1 == null) {
          statement.bindNull(6)
        } else {
          statement.bindText(6, _tmp_1)
        }
        val _tmpError: String? = entity.error
        if (_tmpError == null) {
          statement.bindNull(7)
        } else {
          statement.bindText(7, _tmpError)
        }
        val _tmp_2: Int = if (entity.pending) 1 else 0
        statement.bindLong(8, _tmp_2.toLong())
        statement.bindText(9, entity.blockHash)
        statement.bindLong(10, entity.lastValidBlockHeight)
        statement.bindText(11, entity.base64Encoded)
        statement.bindLong(12, entity.retryCount.toLong())
      }
    }
    this.__insertAdapterOfTokenTransfer = object : EntityInsertAdapter<TokenTransfer>() {
      protected override fun createQuery(): String =
          "INSERT OR IGNORE INTO `TokenTransfer` (`transactionHash`,`mintAddress`,`incoming`,`amount`,`id`) VALUES (?,?,?,?,nullif(?, 0))"

      protected override fun bind(statement: SQLiteStatement, entity: TokenTransfer) {
        statement.bindText(1, entity.transactionHash)
        statement.bindText(2, entity.mintAddress)
        val _tmp: Int = if (entity.incoming) 1 else 0
        statement.bindLong(3, _tmp.toLong())
        val _tmp_1: String? = __roomTypeConverters.bigDecimalToString(entity.amount)
        if (_tmp_1 == null) {
          statement.bindNull(4)
        } else {
          statement.bindText(4, _tmp_1)
        }
        statement.bindLong(5, entity.id)
      }
    }
    this.__updateAdapterOfTransaction = object : EntityDeleteOrUpdateAdapter<Transaction>() {
      protected override fun createQuery(): String =
          "UPDATE OR ABORT `Transaction` SET `hash` = ?,`timestamp` = ?,`fee` = ?,`from` = ?,`to` = ?,`amount` = ?,`error` = ?,`pending` = ?,`blockHash` = ?,`lastValidBlockHeight` = ?,`base64Encoded` = ?,`retryCount` = ? WHERE `hash` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: Transaction) {
        statement.bindText(1, entity.hash)
        statement.bindLong(2, entity.timestamp)
        val _tmpFee: BigDecimal? = entity.fee
        val _tmp: String? = __roomTypeConverters.bigDecimalToString(_tmpFee)
        if (_tmp == null) {
          statement.bindNull(3)
        } else {
          statement.bindText(3, _tmp)
        }
        val _tmpFrom: String? = entity.from
        if (_tmpFrom == null) {
          statement.bindNull(4)
        } else {
          statement.bindText(4, _tmpFrom)
        }
        val _tmpTo: String? = entity.to
        if (_tmpTo == null) {
          statement.bindNull(5)
        } else {
          statement.bindText(5, _tmpTo)
        }
        val _tmpAmount: BigDecimal? = entity.amount
        val _tmp_1: String? = __roomTypeConverters.bigDecimalToString(_tmpAmount)
        if (_tmp_1 == null) {
          statement.bindNull(6)
        } else {
          statement.bindText(6, _tmp_1)
        }
        val _tmpError: String? = entity.error
        if (_tmpError == null) {
          statement.bindNull(7)
        } else {
          statement.bindText(7, _tmpError)
        }
        val _tmp_2: Int = if (entity.pending) 1 else 0
        statement.bindLong(8, _tmp_2.toLong())
        statement.bindText(9, entity.blockHash)
        statement.bindLong(10, entity.lastValidBlockHeight)
        statement.bindText(11, entity.base64Encoded)
        statement.bindLong(12, entity.retryCount.toLong())
        statement.bindText(13, entity.hash)
      }
    }
  }

  public override fun insertTransactions(transactions: List<Transaction>): Unit =
      performBlocking(__db, false, true) { _connection ->
    __insertAdapterOfTransaction.insert(_connection, transactions)
  }

  public override fun insertTokenTransfers(tokenTransfers: List<TokenTransfer>): Unit =
      performBlocking(__db, false, true) { _connection ->
    __insertAdapterOfTokenTransfer.insert(_connection, tokenTransfers)
  }

  public override fun updateTransactions(transactions: List<Transaction>): Unit =
      performBlocking(__db, false, true) { _connection ->
    __updateAdapterOfTransaction.handleMultiple(_connection, transactions)
  }

  public override fun `get`(transactionHash: String): Transaction? {
    val _sql: String = "SELECT * FROM `Transaction` WHERE hash = ? LIMIT 1"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, transactionHash)
        val _columnIndexOfHash: Int = getColumnIndexOrThrow(_stmt, "hash")
        val _columnIndexOfTimestamp: Int = getColumnIndexOrThrow(_stmt, "timestamp")
        val _columnIndexOfFee: Int = getColumnIndexOrThrow(_stmt, "fee")
        val _columnIndexOfFrom: Int = getColumnIndexOrThrow(_stmt, "from")
        val _columnIndexOfTo: Int = getColumnIndexOrThrow(_stmt, "to")
        val _columnIndexOfAmount: Int = getColumnIndexOrThrow(_stmt, "amount")
        val _columnIndexOfError: Int = getColumnIndexOrThrow(_stmt, "error")
        val _columnIndexOfPending: Int = getColumnIndexOrThrow(_stmt, "pending")
        val _columnIndexOfBlockHash: Int = getColumnIndexOrThrow(_stmt, "blockHash")
        val _columnIndexOfLastValidBlockHeight: Int = getColumnIndexOrThrow(_stmt,
            "lastValidBlockHeight")
        val _columnIndexOfBase64Encoded: Int = getColumnIndexOrThrow(_stmt, "base64Encoded")
        val _columnIndexOfRetryCount: Int = getColumnIndexOrThrow(_stmt, "retryCount")
        val _result: Transaction?
        if (_stmt.step()) {
          val _tmpHash: String
          _tmpHash = _stmt.getText(_columnIndexOfHash)
          val _tmpTimestamp: Long
          _tmpTimestamp = _stmt.getLong(_columnIndexOfTimestamp)
          val _tmpFee: BigDecimal?
          val _tmp: String?
          if (_stmt.isNull(_columnIndexOfFee)) {
            _tmp = null
          } else {
            _tmp = _stmt.getText(_columnIndexOfFee)
          }
          _tmpFee = __roomTypeConverters.bigDecimalFromString(_tmp)
          val _tmpFrom: String?
          if (_stmt.isNull(_columnIndexOfFrom)) {
            _tmpFrom = null
          } else {
            _tmpFrom = _stmt.getText(_columnIndexOfFrom)
          }
          val _tmpTo: String?
          if (_stmt.isNull(_columnIndexOfTo)) {
            _tmpTo = null
          } else {
            _tmpTo = _stmt.getText(_columnIndexOfTo)
          }
          val _tmpAmount: BigDecimal?
          val _tmp_1: String?
          if (_stmt.isNull(_columnIndexOfAmount)) {
            _tmp_1 = null
          } else {
            _tmp_1 = _stmt.getText(_columnIndexOfAmount)
          }
          _tmpAmount = __roomTypeConverters.bigDecimalFromString(_tmp_1)
          val _tmpError: String?
          if (_stmt.isNull(_columnIndexOfError)) {
            _tmpError = null
          } else {
            _tmpError = _stmt.getText(_columnIndexOfError)
          }
          val _tmpPending: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfPending).toInt()
          _tmpPending = _tmp_2 != 0
          val _tmpBlockHash: String
          _tmpBlockHash = _stmt.getText(_columnIndexOfBlockHash)
          val _tmpLastValidBlockHeight: Long
          _tmpLastValidBlockHeight = _stmt.getLong(_columnIndexOfLastValidBlockHeight)
          val _tmpBase64Encoded: String
          _tmpBase64Encoded = _stmt.getText(_columnIndexOfBase64Encoded)
          val _tmpRetryCount: Int
          _tmpRetryCount = _stmt.getLong(_columnIndexOfRetryCount).toInt()
          _result =
              Transaction(_tmpHash,_tmpTimestamp,_tmpFee,_tmpFrom,_tmpTo,_tmpAmount,_tmpError,_tmpPending,_tmpBlockHash,_tmpLastValidBlockHeight,_tmpBase64Encoded,_tmpRetryCount)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun lastNonPendingTransaction(): Transaction? {
    val _sql: String =
        "SELECT * FROM `Transaction` WHERE NOT pending ORDER BY timestamp DESC LIMIT 1"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfHash: Int = getColumnIndexOrThrow(_stmt, "hash")
        val _columnIndexOfTimestamp: Int = getColumnIndexOrThrow(_stmt, "timestamp")
        val _columnIndexOfFee: Int = getColumnIndexOrThrow(_stmt, "fee")
        val _columnIndexOfFrom: Int = getColumnIndexOrThrow(_stmt, "from")
        val _columnIndexOfTo: Int = getColumnIndexOrThrow(_stmt, "to")
        val _columnIndexOfAmount: Int = getColumnIndexOrThrow(_stmt, "amount")
        val _columnIndexOfError: Int = getColumnIndexOrThrow(_stmt, "error")
        val _columnIndexOfPending: Int = getColumnIndexOrThrow(_stmt, "pending")
        val _columnIndexOfBlockHash: Int = getColumnIndexOrThrow(_stmt, "blockHash")
        val _columnIndexOfLastValidBlockHeight: Int = getColumnIndexOrThrow(_stmt,
            "lastValidBlockHeight")
        val _columnIndexOfBase64Encoded: Int = getColumnIndexOrThrow(_stmt, "base64Encoded")
        val _columnIndexOfRetryCount: Int = getColumnIndexOrThrow(_stmt, "retryCount")
        val _result: Transaction?
        if (_stmt.step()) {
          val _tmpHash: String
          _tmpHash = _stmt.getText(_columnIndexOfHash)
          val _tmpTimestamp: Long
          _tmpTimestamp = _stmt.getLong(_columnIndexOfTimestamp)
          val _tmpFee: BigDecimal?
          val _tmp: String?
          if (_stmt.isNull(_columnIndexOfFee)) {
            _tmp = null
          } else {
            _tmp = _stmt.getText(_columnIndexOfFee)
          }
          _tmpFee = __roomTypeConverters.bigDecimalFromString(_tmp)
          val _tmpFrom: String?
          if (_stmt.isNull(_columnIndexOfFrom)) {
            _tmpFrom = null
          } else {
            _tmpFrom = _stmt.getText(_columnIndexOfFrom)
          }
          val _tmpTo: String?
          if (_stmt.isNull(_columnIndexOfTo)) {
            _tmpTo = null
          } else {
            _tmpTo = _stmt.getText(_columnIndexOfTo)
          }
          val _tmpAmount: BigDecimal?
          val _tmp_1: String?
          if (_stmt.isNull(_columnIndexOfAmount)) {
            _tmp_1 = null
          } else {
            _tmp_1 = _stmt.getText(_columnIndexOfAmount)
          }
          _tmpAmount = __roomTypeConverters.bigDecimalFromString(_tmp_1)
          val _tmpError: String?
          if (_stmt.isNull(_columnIndexOfError)) {
            _tmpError = null
          } else {
            _tmpError = _stmt.getText(_columnIndexOfError)
          }
          val _tmpPending: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfPending).toInt()
          _tmpPending = _tmp_2 != 0
          val _tmpBlockHash: String
          _tmpBlockHash = _stmt.getText(_columnIndexOfBlockHash)
          val _tmpLastValidBlockHeight: Long
          _tmpLastValidBlockHeight = _stmt.getLong(_columnIndexOfLastValidBlockHeight)
          val _tmpBase64Encoded: String
          _tmpBase64Encoded = _stmt.getText(_columnIndexOfBase64Encoded)
          val _tmpRetryCount: Int
          _tmpRetryCount = _stmt.getLong(_columnIndexOfRetryCount).toInt()
          _result =
              Transaction(_tmpHash,_tmpTimestamp,_tmpFee,_tmpFrom,_tmpTo,_tmpAmount,_tmpError,_tmpPending,_tmpBlockHash,_tmpLastValidBlockHeight,_tmpBase64Encoded,_tmpRetryCount)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun pendingTransactions(): List<Transaction> {
    val _sql: String = "SELECT * FROM `Transaction` WHERE pending ORDER BY timestamp"
    return performBlocking(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfHash: Int = getColumnIndexOrThrow(_stmt, "hash")
        val _columnIndexOfTimestamp: Int = getColumnIndexOrThrow(_stmt, "timestamp")
        val _columnIndexOfFee: Int = getColumnIndexOrThrow(_stmt, "fee")
        val _columnIndexOfFrom: Int = getColumnIndexOrThrow(_stmt, "from")
        val _columnIndexOfTo: Int = getColumnIndexOrThrow(_stmt, "to")
        val _columnIndexOfAmount: Int = getColumnIndexOrThrow(_stmt, "amount")
        val _columnIndexOfError: Int = getColumnIndexOrThrow(_stmt, "error")
        val _columnIndexOfPending: Int = getColumnIndexOrThrow(_stmt, "pending")
        val _columnIndexOfBlockHash: Int = getColumnIndexOrThrow(_stmt, "blockHash")
        val _columnIndexOfLastValidBlockHeight: Int = getColumnIndexOrThrow(_stmt,
            "lastValidBlockHeight")
        val _columnIndexOfBase64Encoded: Int = getColumnIndexOrThrow(_stmt, "base64Encoded")
        val _columnIndexOfRetryCount: Int = getColumnIndexOrThrow(_stmt, "retryCount")
        val _result: MutableList<Transaction> = mutableListOf()
        while (_stmt.step()) {
          val _item: Transaction
          val _tmpHash: String
          _tmpHash = _stmt.getText(_columnIndexOfHash)
          val _tmpTimestamp: Long
          _tmpTimestamp = _stmt.getLong(_columnIndexOfTimestamp)
          val _tmpFee: BigDecimal?
          val _tmp: String?
          if (_stmt.isNull(_columnIndexOfFee)) {
            _tmp = null
          } else {
            _tmp = _stmt.getText(_columnIndexOfFee)
          }
          _tmpFee = __roomTypeConverters.bigDecimalFromString(_tmp)
          val _tmpFrom: String?
          if (_stmt.isNull(_columnIndexOfFrom)) {
            _tmpFrom = null
          } else {
            _tmpFrom = _stmt.getText(_columnIndexOfFrom)
          }
          val _tmpTo: String?
          if (_stmt.isNull(_columnIndexOfTo)) {
            _tmpTo = null
          } else {
            _tmpTo = _stmt.getText(_columnIndexOfTo)
          }
          val _tmpAmount: BigDecimal?
          val _tmp_1: String?
          if (_stmt.isNull(_columnIndexOfAmount)) {
            _tmp_1 = null
          } else {
            _tmp_1 = _stmt.getText(_columnIndexOfAmount)
          }
          _tmpAmount = __roomTypeConverters.bigDecimalFromString(_tmp_1)
          val _tmpError: String?
          if (_stmt.isNull(_columnIndexOfError)) {
            _tmpError = null
          } else {
            _tmpError = _stmt.getText(_columnIndexOfError)
          }
          val _tmpPending: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfPending).toInt()
          _tmpPending = _tmp_2 != 0
          val _tmpBlockHash: String
          _tmpBlockHash = _stmt.getText(_columnIndexOfBlockHash)
          val _tmpLastValidBlockHeight: Long
          _tmpLastValidBlockHeight = _stmt.getLong(_columnIndexOfLastValidBlockHeight)
          val _tmpBase64Encoded: String
          _tmpBase64Encoded = _stmt.getText(_columnIndexOfBase64Encoded)
          val _tmpRetryCount: Int
          _tmpRetryCount = _stmt.getLong(_columnIndexOfRetryCount).toInt()
          _item =
              Transaction(_tmpHash,_tmpTimestamp,_tmpFee,_tmpFrom,_tmpTo,_tmpAmount,_tmpError,_tmpPending,_tmpBlockHash,_tmpLastValidBlockHeight,_tmpBase64Encoded,_tmpRetryCount)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getTransactions(query: SupportSQLiteQuery):
      List<TransactionsDao.FullTransactionWrapper> {
    val _rawQuery: RoomRawQuery = RoomSQLiteQuery.copyFrom(query).toRoomRawQuery()
    val _sql: String = _rawQuery.sql
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _rawQuery.getBindingFunction().invoke(_stmt)
        val _columnIndexOfHash: Int = getColumnIndex(_stmt, "hash")
        val _columnIndexOfTimestamp: Int = getColumnIndex(_stmt, "timestamp")
        val _columnIndexOfFee: Int = getColumnIndex(_stmt, "fee")
        val _columnIndexOfFrom: Int = getColumnIndex(_stmt, "from")
        val _columnIndexOfTo: Int = getColumnIndex(_stmt, "to")
        val _columnIndexOfAmount: Int = getColumnIndex(_stmt, "amount")
        val _columnIndexOfError: Int = getColumnIndex(_stmt, "error")
        val _columnIndexOfPending: Int = getColumnIndex(_stmt, "pending")
        val _columnIndexOfBlockHash: Int = getColumnIndex(_stmt, "blockHash")
        val _columnIndexOfLastValidBlockHeight: Int = getColumnIndex(_stmt, "lastValidBlockHeight")
        val _columnIndexOfBase64Encoded: Int = getColumnIndex(_stmt, "base64Encoded")
        val _columnIndexOfRetryCount: Int = getColumnIndex(_stmt, "retryCount")
        val _collectionTokenTransfersWithMintAccounts:
            ArrayMap<String, MutableList<TransactionsDao.TokenTransferAndMintAccount>> =
            ArrayMap<String, MutableList<TransactionsDao.TokenTransferAndMintAccount>>()
        while (_stmt.step()) {
          val _tmpKey: String
          _tmpKey = _stmt.getText(_columnIndexOfHash)
          if (!_collectionTokenTransfersWithMintAccounts.containsKey(_tmpKey)) {
            _collectionTokenTransfersWithMintAccounts.put(_tmpKey, mutableListOf())
          }
        }
        _stmt.reset()
        __fetchRelationshipTokenTransferAsioHorizontalsystemsSolanakitDatabaseTransactionDaoTransactionsDaoTokenTransferAndMintAccount(_connection,
            _collectionTokenTransfersWithMintAccounts)
        val _result: MutableList<TransactionsDao.FullTransactionWrapper> = mutableListOf()
        while (_stmt.step()) {
          val _item: TransactionsDao.FullTransactionWrapper
          val _tmpTransaction: Transaction
          val _tmpHash: String
          if (_columnIndexOfHash == -1) {
            error("Missing value for a NON-NULL column 'hash', found NULL value instead.")
          } else {
            _tmpHash = _stmt.getText(_columnIndexOfHash)
          }
          val _tmpTimestamp: Long
          if (_columnIndexOfTimestamp == -1) {
            _tmpTimestamp = 0
          } else {
            _tmpTimestamp = _stmt.getLong(_columnIndexOfTimestamp)
          }
          val _tmpFee: BigDecimal?
          if (_columnIndexOfFee == -1) {
            _tmpFee = null
          } else {
            val _tmp: String?
            if (_stmt.isNull(_columnIndexOfFee)) {
              _tmp = null
            } else {
              _tmp = _stmt.getText(_columnIndexOfFee)
            }
            _tmpFee = __roomTypeConverters.bigDecimalFromString(_tmp)
          }
          val _tmpFrom: String?
          if (_columnIndexOfFrom == -1) {
            _tmpFrom = null
          } else {
            if (_stmt.isNull(_columnIndexOfFrom)) {
              _tmpFrom = null
            } else {
              _tmpFrom = _stmt.getText(_columnIndexOfFrom)
            }
          }
          val _tmpTo: String?
          if (_columnIndexOfTo == -1) {
            _tmpTo = null
          } else {
            if (_stmt.isNull(_columnIndexOfTo)) {
              _tmpTo = null
            } else {
              _tmpTo = _stmt.getText(_columnIndexOfTo)
            }
          }
          val _tmpAmount: BigDecimal?
          if (_columnIndexOfAmount == -1) {
            _tmpAmount = null
          } else {
            val _tmp_1: String?
            if (_stmt.isNull(_columnIndexOfAmount)) {
              _tmp_1 = null
            } else {
              _tmp_1 = _stmt.getText(_columnIndexOfAmount)
            }
            _tmpAmount = __roomTypeConverters.bigDecimalFromString(_tmp_1)
          }
          val _tmpError: String?
          if (_columnIndexOfError == -1) {
            _tmpError = null
          } else {
            if (_stmt.isNull(_columnIndexOfError)) {
              _tmpError = null
            } else {
              _tmpError = _stmt.getText(_columnIndexOfError)
            }
          }
          val _tmpPending: Boolean
          if (_columnIndexOfPending == -1) {
            _tmpPending = false
          } else {
            val _tmp_2: Int
            _tmp_2 = _stmt.getLong(_columnIndexOfPending).toInt()
            _tmpPending = _tmp_2 != 0
          }
          val _tmpBlockHash: String
          if (_columnIndexOfBlockHash == -1) {
            error("Missing value for a NON-NULL column 'blockHash', found NULL value instead.")
          } else {
            _tmpBlockHash = _stmt.getText(_columnIndexOfBlockHash)
          }
          val _tmpLastValidBlockHeight: Long
          if (_columnIndexOfLastValidBlockHeight == -1) {
            _tmpLastValidBlockHeight = 0
          } else {
            _tmpLastValidBlockHeight = _stmt.getLong(_columnIndexOfLastValidBlockHeight)
          }
          val _tmpBase64Encoded: String
          if (_columnIndexOfBase64Encoded == -1) {
            error("Missing value for a NON-NULL column 'base64Encoded', found NULL value instead.")
          } else {
            _tmpBase64Encoded = _stmt.getText(_columnIndexOfBase64Encoded)
          }
          val _tmpRetryCount: Int
          if (_columnIndexOfRetryCount == -1) {
            _tmpRetryCount = 0
          } else {
            _tmpRetryCount = _stmt.getLong(_columnIndexOfRetryCount).toInt()
          }
          _tmpTransaction =
              Transaction(_tmpHash,_tmpTimestamp,_tmpFee,_tmpFrom,_tmpTo,_tmpAmount,_tmpError,_tmpPending,_tmpBlockHash,_tmpLastValidBlockHeight,_tmpBase64Encoded,_tmpRetryCount)
          val _tmpTokenTransfersWithMintAccountsCollection:
              MutableList<TransactionsDao.TokenTransferAndMintAccount>
          val _tmpKey_1: String
          _tmpKey_1 = _stmt.getText(_columnIndexOfHash)
          _tmpTokenTransfersWithMintAccountsCollection =
              _collectionTokenTransfersWithMintAccounts.getValue(_tmpKey_1)
          _item =
              TransactionsDao.FullTransactionWrapper(_tmpTransaction,_tmpTokenTransfersWithMintAccountsCollection)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  private
      fun __fetchRelationshipMintAccountAsioHorizontalsystemsSolanakitModelsMintAccount(_connection: SQLiteConnection,
      _map: ArrayMap<String, MintAccount?>) {
    val __mapKeySet: Set<String> = _map.keys
    if (__mapKeySet.isEmpty()) {
      return
    }
    if (_map.size > 999) {
      recursiveFetchArrayMap(_map, false) { _tmpMap ->
        __fetchRelationshipMintAccountAsioHorizontalsystemsSolanakitModelsMintAccount(_connection,
            _tmpMap)
      }
      return
    }
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT `address`,`decimals`,`supply`,`isNft`,`name`,`symbol`,`uri`,`collectionAddress` FROM `MintAccount` WHERE `address` IN (")
    val _inputSize: Int = __mapKeySet.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    val _stmt: SQLiteStatement = _connection.prepare(_sql)
    var _argIndex: Int = 1
    for (_item: String in __mapKeySet) {
      _stmt.bindText(_argIndex, _item)
      _argIndex++
    }
    try {
      val _itemKeyIndex: Int = getColumnIndex(_stmt, "address")
      if (_itemKeyIndex == -1) {
        return
      }
      val _columnIndexOfAddress: Int = 0
      val _columnIndexOfDecimals: Int = 1
      val _columnIndexOfSupply: Int = 2
      val _columnIndexOfIsNft: Int = 3
      val _columnIndexOfName: Int = 4
      val _columnIndexOfSymbol: Int = 5
      val _columnIndexOfUri: Int = 6
      val _columnIndexOfCollectionAddress: Int = 7
      while (_stmt.step()) {
        val _tmpKey: String
        _tmpKey = _stmt.getText(_itemKeyIndex)
        if (_map.containsKey(_tmpKey)) {
          val _item_1: MintAccount
          val _tmpAddress: String
          _tmpAddress = _stmt.getText(_columnIndexOfAddress)
          val _tmpDecimals: Int
          _tmpDecimals = _stmt.getLong(_columnIndexOfDecimals).toInt()
          val _tmpSupply: Long?
          if (_stmt.isNull(_columnIndexOfSupply)) {
            _tmpSupply = null
          } else {
            _tmpSupply = _stmt.getLong(_columnIndexOfSupply)
          }
          val _tmpIsNft: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfIsNft).toInt()
          _tmpIsNft = _tmp != 0
          val _tmpName: String?
          if (_stmt.isNull(_columnIndexOfName)) {
            _tmpName = null
          } else {
            _tmpName = _stmt.getText(_columnIndexOfName)
          }
          val _tmpSymbol: String?
          if (_stmt.isNull(_columnIndexOfSymbol)) {
            _tmpSymbol = null
          } else {
            _tmpSymbol = _stmt.getText(_columnIndexOfSymbol)
          }
          val _tmpUri: String?
          if (_stmt.isNull(_columnIndexOfUri)) {
            _tmpUri = null
          } else {
            _tmpUri = _stmt.getText(_columnIndexOfUri)
          }
          val _tmpCollectionAddress: String?
          if (_stmt.isNull(_columnIndexOfCollectionAddress)) {
            _tmpCollectionAddress = null
          } else {
            _tmpCollectionAddress = _stmt.getText(_columnIndexOfCollectionAddress)
          }
          _item_1 =
              MintAccount(_tmpAddress,_tmpDecimals,_tmpSupply,_tmpIsNft,_tmpName,_tmpSymbol,_tmpUri,_tmpCollectionAddress)
          _map.put(_tmpKey, _item_1)
        }
      }
    } finally {
      _stmt.close()
    }
  }

  private
      fun __fetchRelationshipTokenTransferAsioHorizontalsystemsSolanakitDatabaseTransactionDaoTransactionsDaoTokenTransferAndMintAccount(_connection: SQLiteConnection,
      _map: ArrayMap<String, MutableList<TransactionsDao.TokenTransferAndMintAccount>>) {
    val __mapKeySet: Set<String> = _map.keys
    if (__mapKeySet.isEmpty()) {
      return
    }
    if (_map.size > 999) {
      recursiveFetchArrayMap(_map, true) { _tmpMap ->
        __fetchRelationshipTokenTransferAsioHorizontalsystemsSolanakitDatabaseTransactionDaoTransactionsDaoTokenTransferAndMintAccount(_connection,
            _tmpMap)
      }
      return
    }
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT `transactionHash`,`mintAddress`,`incoming`,`amount`,`id` FROM `TokenTransfer` WHERE `transactionHash` IN (")
    val _inputSize: Int = __mapKeySet.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    val _stmt: SQLiteStatement = _connection.prepare(_sql)
    var _argIndex: Int = 1
    for (_item: String in __mapKeySet) {
      _stmt.bindText(_argIndex, _item)
      _argIndex++
    }
    try {
      val _itemKeyIndex: Int = getColumnIndex(_stmt, "transactionHash")
      if (_itemKeyIndex == -1) {
        return
      }
      val _columnIndexOfTransactionHash: Int = 0
      val _columnIndexOfMintAddress: Int = 1
      val _columnIndexOfIncoming: Int = 2
      val _columnIndexOfAmount: Int = 3
      val _columnIndexOfId: Int = 4
      val _collectionMintAccount: ArrayMap<String, MintAccount?> = ArrayMap<String, MintAccount?>()
      while (_stmt.step()) {
        val _tmpKey: String
        _tmpKey = _stmt.getText(_columnIndexOfMintAddress)
        _collectionMintAccount.put(_tmpKey, null)
      }
      _stmt.reset()
      __fetchRelationshipMintAccountAsioHorizontalsystemsSolanakitModelsMintAccount(_connection,
          _collectionMintAccount)
      while (_stmt.step()) {
        val _tmpKey_1: String
        _tmpKey_1 = _stmt.getText(_itemKeyIndex)
        val _tmpRelation: MutableList<TransactionsDao.TokenTransferAndMintAccount>? =
            _map.get(_tmpKey_1)
        if (_tmpRelation != null) {
          val _item_1: TransactionsDao.TokenTransferAndMintAccount
          val _tmpTokenTransfer: TokenTransfer
          val _tmpTransactionHash: String
          _tmpTransactionHash = _stmt.getText(_columnIndexOfTransactionHash)
          val _tmpMintAddress: String
          _tmpMintAddress = _stmt.getText(_columnIndexOfMintAddress)
          val _tmpIncoming: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfIncoming).toInt()
          _tmpIncoming = _tmp != 0
          val _tmpAmount: BigDecimal
          val _tmp_1: String?
          if (_stmt.isNull(_columnIndexOfAmount)) {
            _tmp_1 = null
          } else {
            _tmp_1 = _stmt.getText(_columnIndexOfAmount)
          }
          val _tmp_2: BigDecimal? = __roomTypeConverters.bigDecimalFromString(_tmp_1)
          if (_tmp_2 == null) {
            error("Expected NON-NULL 'java.math.BigDecimal', but it was NULL.")
          } else {
            _tmpAmount = _tmp_2
          }
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          _tmpTokenTransfer =
              TokenTransfer(_tmpTransactionHash,_tmpMintAddress,_tmpIncoming,_tmpAmount,_tmpId)
          val _tmpMintAccount: MintAccount?
          val _tmpKey_2: String
          _tmpKey_2 = _stmt.getText(_columnIndexOfMintAddress)
          _tmpMintAccount = _collectionMintAccount.get(_tmpKey_2)
          if (_tmpMintAccount == null) {
            error("Relationship item 'mintAccount' was expected to be NON-NULL but is NULL in @Relation involving a parent column named 'mintAddress' and entityColumn named 'address'.")
          }
          _item_1 = TransactionsDao.TokenTransferAndMintAccount(_tmpTokenTransfer,_tmpMintAccount)
          _tmpRelation.add(_item_1)
        }
      }
    } finally {
      _stmt.close()
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
